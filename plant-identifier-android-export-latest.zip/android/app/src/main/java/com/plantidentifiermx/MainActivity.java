package com.plantidentifiermx;

import com.facebook.react.ReactActivity;

public class MainActivity extends ReactActivity {
    @Override
    protected String getMainComponentName() {
        return "plant-identifier-mx";
    }
}